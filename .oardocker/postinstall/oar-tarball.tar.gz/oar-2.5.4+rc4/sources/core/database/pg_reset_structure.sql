
DROP TABLE schema; 
DROP TABLE jobs;
DROP TABLE job_types;
DROP TABLE challenges;
DROP TABLE moldable_job_descriptions;
DROP TABLE job_resource_groups;
DROP TABLE job_resource_descriptions;
DROP TABLE job_state_logs;
DROP TABLE frag_jobs;
DROP TABLE assigned_resources;
DROP TABLE resources;
DROP TABLE resource_logs;
DROP TABLE queues;
DROP TABLE scheduler;
DROP TABLE admission_rules;
DROP TABLE gantt_jobs_predictions;
DROP TABLE gantt_jobs_predictions_visu;
DROP TABLE gantt_jobs_predictions_log;
DROP TABLE gantt_jobs_resources;
DROP TABLE gantt_jobs_resources_visu;
DROP TABLE gantt_jobs_resources_log;
DROP TABLE files;
DROP TABLE event_logs;
DROP TABLE event_log_hostnames;
DROP TABLE accounting;
DROP TABLE job_dependencies;

