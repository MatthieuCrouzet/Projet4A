$HTML_HEADER = "
<HTML>
<HEAD>
<TITLE>OAR REST API</TITLE>
</HEAD>
<BODY>
<HR>
<A HREF=$apiuri/resources.html>RESOURCES</A>&nbsp;&nbsp;&nbsp;
<A HREF=$apiuri/resources/form.html>GENERATE RESOURCES</A>&nbsp;&nbsp;&nbsp;
<A HREF=$apiuri/jobs.html>JOBS</A>&nbsp;&nbsp;&nbsp;
<A HREF=$apiuri/jobs/form.html>JOB SUBMISSION</A>&nbsp;&nbsp;&nbsp;
<A HREF=$apiuri/admission_rules.html>ADMISSION RULES</A>&nbsp;&nbsp;&nbsp;
<A HREF=$apiuri/admission_rules/form.html>RULE SUBMISSION</A>&nbsp;&nbsp;&nbsp;
<A HREF=$apiuri/config.html>CONFIGURATION</A>&nbsp;&nbsp;&nbsp;
<HR>
"

