.. image:: ../schemas/oar_logo.png
   :alt: OAR logo
   :align: center
   :width: 8cm

:Authors: Capit Nicolas, Emeras Joseph
:Address: Laboratoire d'Informatique de Grenoble 
          Bat. ENSIMAG - antenne de Montbonnot
          ZIRST 51, avenue Jean Kuntzmann
          38330 MONTBONNOT SAINT MARTIN
:Contact: nicolas.capit@imag.fr, joseph.emeras@imag.fr
:Authors: LIG laboratory
:Organization: LIG laboratory
:Status: Stable
:Copyright: licenced under the GNU GENERAL PUBLIC LICENSE
