 Scheduler Test Tools
======================

Todo
====

* load conf from /etc/oar/oar.conf
* function to modify oar.conf
* simple tests (new file ?)
* use REST API
* doc doc

