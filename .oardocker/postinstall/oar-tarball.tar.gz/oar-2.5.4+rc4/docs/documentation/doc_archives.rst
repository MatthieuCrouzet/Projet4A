OAR Archives
============

There are several mini-projects for and around OAR that has been done since the
beginning. Some of them are not currently used or are no more relevant. To keep
a trace for memories and for the possibility to reuse them if needed, we have
created a branche 'archives' in the OAR source repository to keep them. Here
are the list of them.

module Accounting
-----------------

desktop_computing
-----------------

drmaa-c
-------

moldable
--------

ocaml-schedulers
----------------

poar
----

poar-proto
----------

testsuite
---------

tgoar
-----

