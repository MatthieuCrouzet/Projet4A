:Abstract:

  OAR is a resource manager (or batch scheduler) for large clusters. By it's
  functionnalities, it's near of PBS, LSF, CCS and Condor. It's suitable for
  productive plateforms and research experiments.

