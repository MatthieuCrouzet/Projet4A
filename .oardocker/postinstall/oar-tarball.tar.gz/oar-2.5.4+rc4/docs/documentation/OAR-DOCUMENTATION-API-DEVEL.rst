====================================================
 OAR Documentation - REST API - Developper's guide
====================================================

:Dedication: For OAR developpers whishing to add or modify features of the REST API (not for developpers of third party products that make use of the OAR REST API: read the User's guide)

.. include:: doc_abstract.rst

**BE CAREFULL : THIS DOCUMENTATION IS FOR OAR >= 2.5.0**

PDF version : `<OAR-DOCUMENTATION-API-DEVEL.pdf>`_

.. section-numbering::
.. contents:: Table of Contents

-------------------------------------------------------------------------------

Introduction
============

...To be written...


How does it work
================

...To be written...

Sources organization
====================

...To be written...

Rspec tests
===========

...To be written...
