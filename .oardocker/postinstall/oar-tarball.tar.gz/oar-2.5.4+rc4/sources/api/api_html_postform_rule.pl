$POSTFORM="
<FORM METHOD=post ACTION=$apiuri/admission_rules.html>
<TABLE>
<CAPTION>Admission rule submission</CAPTION>
<TR>
  <TD>Rule</TD>
  <TD><TEXTAREA name=rule COLS=70 ROWS=10></TEXTAREA></TD>
</TR><TR>
  <TD></TD><TD><INPUT TYPE=submit VALUE=SUBMIT></TD>
</TR>
</TABLE>
</FORM>
"

