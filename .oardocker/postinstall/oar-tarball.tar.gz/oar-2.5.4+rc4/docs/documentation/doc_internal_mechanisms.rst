Internal mechanisms
===================

Job execution
-------------
   
.. figure:: ../schemas/job_execution.png

--------------------------------------------------------------------------------   

Scheduling
----------
   
   .. figure:: ../schemas/scheduling.png

